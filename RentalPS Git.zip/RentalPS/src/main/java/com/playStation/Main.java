
package main.java.com.playStation;
import main.java.com.playStation.model.LoginModel;
import main.java.com.playStation.view.admin_Login;
import main.java.com.playStation.controller.LoginController;
import main.java.com.playStation.view.tampilan_UpdatePesanan;
import main.java.com.playStation.view.tampilan_DataCustomer;
import main.java.com.playStation.view.tampilan_Utama2;

public class Main {
    
    public static void main (String[] args) {
        //RUN PROGRAM
        admin_Login form  = new admin_Login();
        //tampilan_UpdatePesanan form = new tampilan_UpdatePesanan();
        //tampilan_DataCustomer form = new tampilan_DataCustomer();
        //tampilan_Utama2 form = new tampilan_Utama2();
        form.setVisible(true);
        
    }
    
}
