package main.java.com.playStation.view;

import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import main.java.com.playStation.controller.PesananController;
import main.java.com.playStation.model.BookingPesnan;

public class pesanan extends javax.swing.JFrame {
    private PesananController pesan1;
    
    // Creates new form admin_Login
     
    public pesanan() {
        pesan1 = new PesananController(new BookingPesnan(), this);
        initComponents();
        this.setLocationRelativeTo(null);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        JBTN1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        comboPodPs5 = new javax.swing.JComboBox<>();
        comboPodPs4 = new javax.swing.JComboBox<>();
        comboPs = new javax.swing.JComboBox<>();
        jmlhFieldMakan = new javax.swing.JTextField();
        txtFieldCustomer = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtFieldDurasi = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        comboMakanan = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        comboMinuman = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        btnTambahPesan = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        daftarTxtArea = new javax.swing.JTextArea();
        jmlhFieldMinum = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        comboStik = new javax.swing.JComboBox<>();
        btnPesanSkrng = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admint Dasbord - Booking PS");

        jPanel1.setBackground(new java.awt.Color(248, 186, 41));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("HP Simplified Light", 1, 14)); // NOI18N
        jLabel1.setText("Admint Dasbord - Booking PS - Pilih POD dan Cemilan");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 400, 30));

        JBTN1.setBackground(new java.awt.Color(0, 0, 0));
        JBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        JBTN1.setText("BACK");
        JBTN1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JBTN1MouseClicked(evt);
            }
        });
        JBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTN1ActionPerformed(evt);
            }
        });
        jPanel2.add(JBTN1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 0, 70, 30));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/logokecil.png"))); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 30));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 420, -1, -1));

        jPanel3.setBackground(new java.awt.Color(27, 33, 92));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        comboPodPs5.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboPodPs5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Pod  06", "Pod  07", "Pod  08", "Pod  09", "Pod  10" }));
        jPanel3.add(comboPodPs5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 190, 50));

        comboPodPs4.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboPodPs4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Pod  01", "Pod  02", "Pod  03", "Pod  04", "Pod  05" }));
        jPanel3.add(comboPodPs4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 150, 50));

        comboPs.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboPs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PlayStation 4", "PlayStation 5" }));
        jPanel3.add(comboPs, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 360, 50));

        jmlhFieldMakan.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jPanel3.add(jmlhFieldMakan, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 410, 150, 50));

        txtFieldCustomer.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        txtFieldCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldCustomerActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 360, 50));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Pilih PlayStation");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 150, 30));

        txtFieldDurasi.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jPanel3.add(txtFieldDurasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 190, 50));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nama Customer");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 150, 30));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Jumlah");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 150, 30));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Pesan Makanan ");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 150, 30));

        comboMakanan.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboMakanan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Indomie Kuah", "Indomie Goreng", "Fries & Saussages", " " }));
        jPanel3.add(comboMakanan, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 190, 50));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Durasi(Jam)");
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 130, 30));

        jLabel10.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("PS 5 :");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, -1));

        jLabel7.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("PS 4 :");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/OrangePutih.png"))); // NOI18N
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(-660, 0, 1160, 550));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 480, 530));

        jPanel4.setBackground(new java.awt.Color(27, 33, 92));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Pesan Minuman ");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 150, 30));

        comboMinuman.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboMinuman.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Milktea Ice", "Kopi", "Air Mineral" }));
        comboMinuman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMinumanActionPerformed(evt);
            }
        });
        jPanel4.add(comboMinuman, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 360, 50));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Daftar Pesanan");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 380, 30));

        btnTambahPesan.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        btnTambahPesan.setText("Tambah");
        btnTambahPesan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTambahPesanMouseClicked(evt);
            }
        });
        jPanel4.add(btnTambahPesan, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 360, 50));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Jumlah");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 150, 30));

        daftarTxtArea.setEditable(false);
        daftarTxtArea.setColumns(20);
        daftarTxtArea.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        daftarTxtArea.setRows(5);
        jScrollPane1.setViewportView(daftarTxtArea);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 360, -1));

        jmlhFieldMinum.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jPanel4.add(jmlhFieldMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 150, 50));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("DualShock");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 150, 30));

        comboStik.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        comboStik.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2" }));
        jPanel4.add(comboStik, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 150, 50));

        btnPesanSkrng.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        btnPesanSkrng.setText("Buat Pesanan Sekarang");
        btnPesanSkrng.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPesanSkrngMouseClicked(evt);
            }
        });
        btnPesanSkrng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesanSkrngActionPerformed(evt);
            }
        });
        jPanel4.add(btnPesanSkrng, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 290, 50));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/OrangePutih.png"))); // NOI18N
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(-660, 0, 1160, 550));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 50, 480, 530));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTN1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JBTN1ActionPerformed

    private void btnPesanSkrngActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesanSkrngActionPerformed
        // 1. Buat objek 'wadah' dari kelas Model Anda   
    }//GEN-LAST:event_btnPesanSkrngActionPerformed

    private void btnTambahPesanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTambahPesanMouseClicked
        pesan1.ambilNilai();
    }//GEN-LAST:event_btnTambahPesanMouseClicked

    private void txtFieldCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldCustomerActionPerformed
        
    }//GEN-LAST:event_txtFieldCustomerActionPerformed

    private void JBTN1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBTN1MouseClicked
        // Membuat instance baru dari tampilan utama
        tampilan_Utama2 tampilanUtama = new tampilan_Utama2();
        // Menampilkan tampilan utama
        tampilanUtama.setVisible(true);
        // Menutup jendela pesanan saat ini
        this.dispose();
    }//GEN-LAST:event_JBTN1MouseClicked

    private void btnPesanSkrngMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPesanSkrngMouseClicked
        // TODO add your handling code here:
        pesan1.pindahFrame();
    }//GEN-LAST:event_btnPesanSkrngMouseClicked

    private void comboMinumanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMinumanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboMinumanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pesanan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBTN1;
    private javax.swing.JButton btnPesanSkrng;
    private javax.swing.JButton btnTambahPesan;
    private javax.swing.JComboBox<String> comboMakanan;
    private javax.swing.JComboBox<String> comboMinuman;
    private javax.swing.JComboBox<String> comboPodPs4;
    private javax.swing.JComboBox<String> comboPodPs5;
    private javax.swing.JComboBox<String> comboPs;
    private javax.swing.JComboBox<String> comboStik;
    private javax.swing.JTextArea daftarTxtArea;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jmlhFieldMakan;
    private javax.swing.JTextField jmlhFieldMinum;
    private javax.swing.JTextField txtFieldCustomer;
    private javax.swing.JTextField txtFieldDurasi;
    // End of variables declaration//GEN-END:variables
    
    //getter setter
    public JButton getBtnPesanSkrng() {
        return btnPesanSkrng;
    }

    public void setBtnPesanSkrng(JButton btnPesanSkrng) {
        this.btnPesanSkrng = btnPesanSkrng;
    }

    public JButton getBtnTambahPesan() {
        return btnTambahPesan;
    }

    public void setBtnTambahPesan(JButton btnTambahPesan) {
        this.btnTambahPesan = btnTambahPesan;
    }

    public PesananController getPesan1() {
        return pesan1;
    }

    public void setPesan1(PesananController pesan1) {
        this.pesan1 = pesan1;
    }

    public JComboBox<String> getComboPodPs4() {
        return comboPodPs4;
    }

    public void setComboPodPs4(JComboBox<String> comboPodPs4) {
        this.comboPodPs4 = comboPodPs4;
    }

    public JComboBox<String> getComboPodPs5() {
        return comboPodPs5;
    }

    public void setComboPodPs5(JComboBox<String> comboPodPs5) {
        this.comboPodPs5 = comboPodPs5;
    }

    public JTextField getJmlhField() {
        return jmlhFieldMinum;
    }

    public void setJmlhField(JTextField jmlhField) {
        this.jmlhFieldMinum = jmlhField;
    }


    public JComboBox<String> getComboMakanan() {
        return comboMakanan;
    }

    public void setComboMakanan(JComboBox<String> comboMakanan) {
        this.comboMakanan = comboMakanan;
    }

    public JComboBox<String> getComboMinuman() {
        return comboMinuman;
    }

    public void setComboMinuman(JComboBox<String> comboMinuman) {
        this.comboMinuman = comboMinuman;
    }

    public JComboBox<String> getComboPod() {
        return comboPodPs5;
    }

    public void setComboPod(JComboBox<String> comboPod) {
        this.comboPodPs5 = comboPod;
    }

    public JComboBox<String> getComboPs() {
        return comboPs;
    }

    public void setComboPs(JComboBox<String> comboPs) {
        this.comboPs = comboPs;
    }

    public JComboBox<String> getComboStik() {
        return comboStik;
    }

    public void setComboStik(JComboBox<String> comboStik) {
        this.comboStik = comboStik;
    }

    public JTextArea getDaftarTxtArea() {
        return daftarTxtArea;
    }

    public void setDaftarTxtArea(JTextArea daftarTxtArea) {
        this.daftarTxtArea = daftarTxtArea;
    }

    public JTextField getTxtFieldCustomer() {
        return txtFieldCustomer;
    }

    public void setTxtFieldCustomer(JTextField txtFieldCustomer) {
        this.txtFieldCustomer = txtFieldCustomer;
    }

    public JTextField getTxtFieldDurasi() {
        return txtFieldDurasi;
    }

    public void setTxtFieldDurasi(JTextField txtFieldDurasi) {
        this.txtFieldDurasi = txtFieldDurasi;
    }

    public JTextField getJmlhFieldMinum() {
        return jmlhFieldMinum;
    }

    public void setJmlhFieldMinum(JTextField jmlhFieldMinum) {
        this.jmlhFieldMinum = jmlhFieldMinum;
    }

    

    public JTextField getJmlhFieldMakan() {
        return jmlhFieldMakan;
    }

    public void setJmlhFieldMakan(JTextField jmlhFieldMakan) {
        this.jmlhFieldMakan = jmlhFieldMakan;
    }
    
    

}
