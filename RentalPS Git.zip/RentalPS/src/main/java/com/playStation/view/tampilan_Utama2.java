package main.java.com.playStation.view;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class tampilan_Utama2 extends javax.swing.JFrame {

    
     // Creates new form admin_Login
     
    public tampilan_Utama2() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        JBTN = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        bookingLabel = new javax.swing.JLabel();
        dataCustomerLabel = new javax.swing.JLabel();
        updateDataLabel = new javax.swing.JLabel();
        laporanLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admint Login - Welcome to DeppraPlayStation");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("HP Simplified Light", 1, 14)); // NOI18N
        jLabel1.setText("Admint Dasbord - Welcome Admint!!");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 250, 30));

        JBTN.setBackground(new java.awt.Color(0, 0, 0));
        JBTN.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        JBTN.setText("LOG OUT");
        JBTN.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        JBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JBTNMouseClicked(evt);
            }
        });
        JBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTNActionPerformed(evt);
            }
        });
        jPanel2.add(JBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 0, 90, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/logokecil.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/LogoRentalBaru.png"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, 480, -1));

        bookingLabel.setBackground(new java.awt.Color(255, 255, 255));
        bookingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bookingLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/BookingPSRill.png"))); // NOI18N
        bookingLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookingLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bookingLabelMouseEntered(evt);
            }
        });
        jPanel1.add(bookingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 260, 200));

        dataCustomerLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dataCustomerLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/DataCustomer.png"))); // NOI18N
        dataCustomerLabel.setText("jLabel3");
        dataCustomerLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataCustomerLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dataCustomerLabelMouseEntered(evt);
            }
        });
        jPanel1.add(dataCustomerLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 270, 210));

        updateDataLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        updateDataLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/UpdateDataCustomer.png"))); // NOI18N
        updateDataLabel.setText("jLabel3");
        updateDataLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateDataLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                updateDataLabelMouseEntered(evt);
            }
        });
        jPanel1.add(updateDataLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 70, 270, 200));

        laporanLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        laporanLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/java/com/playStation/view/referensiGambar/LaporanLogo.png"))); // NOI18N
        laporanLabel.setText("jLabel2");
        laporanLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                laporanLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                laporanLabelMouseEntered(evt);
            }
        });
        jPanel1.add(laporanLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 310, 260, 220));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTNActionPerformed
        
    }//GEN-LAST:event_JBTNActionPerformed

    private void bookingLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookingLabelMouseClicked
        pesanan pesan = new pesanan();
        pesan.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_bookingLabelMouseClicked

    private void bookingLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookingLabelMouseEntered
        // TODO add your handling code here:
        bookingLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_bookingLabelMouseEntered

    private void dataCustomerLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataCustomerLabelMouseClicked
        tampilan_DataCustomer dataCustomer = new tampilan_DataCustomer();
        dataCustomer.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_dataCustomerLabelMouseClicked

    private void dataCustomerLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataCustomerLabelMouseEntered
        dataCustomerLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_dataCustomerLabelMouseEntered

    private void updateDataLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateDataLabelMouseClicked

        tampilan_UpdatePesanan updatePesanan = new tampilan_UpdatePesanan();
        updatePesanan.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_updateDataLabelMouseClicked

    private void updateDataLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateDataLabelMouseEntered
        updateDataLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_updateDataLabelMouseEntered

    private void laporanLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporanLabelMouseClicked
        // TODO add your handling code here:
        //informasiPesanan informasi = new informasiPesanan();
        //informasi.setVisible(true);
        //this.dispose();
    }//GEN-LAST:event_laporanLabelMouseClicked

    private void laporanLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporanLabelMouseEntered
        laporanLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_laporanLabelMouseEntered

    private void JBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBTNMouseClicked
        // Membuat instance baru dari tampilan utama
        admin_Login adminLogin = new admin_Login();
        // Menampilkan tampilan utama
        adminLogin.setVisible(true);
        // Menutup jendela pesanan saat ini
        this.dispose();
        JOptionPane.showMessageDialog(null, 
                    "Telah LogOut", 
                    "Logout Berhasil!!",
                    JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_JBTNMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tampilan_Utama2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tampilan_Utama2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tampilan_Utama2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tampilan_Utama2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tampilan_Utama2().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBTN;
    private javax.swing.JLabel bookingLabel;
    private javax.swing.JLabel dataCustomerLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel laporanLabel;
    private javax.swing.JLabel updateDataLabel;
    // End of variables declaration//GEN-END:variables
    public JButton getJBTN() {
        return JBTN;
    }
    public void setJBTN(JButton JBTN) {
        this.JBTN = JBTN;
    }
}
