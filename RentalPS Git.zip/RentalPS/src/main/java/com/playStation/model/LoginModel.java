
package main.java.com.playStation.model;


public class LoginModel {
    //properties akun data login
    private String username = "admin123";
    private String password = "admin123";
    
    //getter setter
    public String getAkun() {
        return username;
    }

    public void setAkun(String akun) {
        this.username = akun;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    //method pengecekan apakah sama atau tidak
    public boolean checkLogin(String inputUser, String inputPass) {
        return inputUser.equals(username) && inputPass.equals(password);
    }
    
    
}
