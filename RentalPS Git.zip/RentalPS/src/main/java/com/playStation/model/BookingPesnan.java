package main.java.com.playStation.model;
import java.util.HashMap;
import java.util.Map;

public class BookingPesnan {
    // Properti untuk menampung semua data dari form booking
    private String namaCustomer;
    private String jenisPS;
    private String nomorPod1;
    private String nomorPod2;
    private String jenisMakanan;
    private String jenisMinuman;
    private int durasi;
    private int jumlahMakanan;
    private int jumlahMinuman;
    private int tambahanStik;

    private int totalHarga;

    // --- Getter Setter ---

    public String getNamaCustomer() {
        return namaCustomer;
    }

    public void setNamaCustomer(String namaCustomer) {
        this.namaCustomer = namaCustomer;
    }

    public String getJenisPS() {
        return jenisPS;
    }

    public void setJenisPS(String jenisPS) {
        this.jenisPS = jenisPS;
    }

    public String getNomorPod1() {
        return nomorPod1;
    }

    public void setNomorPod1(String nomorPod1) {
        this.nomorPod1 = nomorPod1;
    }

    public String getNomorPod2() {
        return nomorPod2;
    }

    public void setNomorPod2(String nomorPod2) {
        this.nomorPod2 = nomorPod2;
    }

    public int getDurasi() {
        return durasi;
    }

    public void setDurasi(int durasi) {
        this.durasi = durasi;
    }

    public int getJumlahMakanan() {
        return jumlahMakanan;
    }

    public void setJumlahMakanan(int jumlahMakanan) {
        this.jumlahMakanan = jumlahMakanan;
    }

    public int getJumlahMinuman() {
        return jumlahMinuman;
    }

    public void setJumlahMinuman(int jumlahMinuman) {
        this.jumlahMinuman = jumlahMinuman;
    }

    public int getTambahanStik() {
        return tambahanStik;
    }

    public void setTambahanStik(int tambahanStik) {
        this.tambahanStik = tambahanStik;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(int totalHarga) {
        this.totalHarga = totalHarga;
    }

    public String getJenisMakanan() {
        return jenisMakanan;
    }

    public void setJenisMakanan(String jenisMakanan) {
        this.jenisMakanan = jenisMakanan;
    }

    public String getJenisMinuman() {
        return jenisMinuman;
    }

    public void setJenisMinuman(String jenisMinuman) {
        this.jenisMinuman = jenisMinuman;
    }
    
    
    
    
    // === DAFTAR HARGA MAKANAN DAN MINUMAN ===
    public static final Map<String, Integer> HARGA_MAKANAN = new HashMap<>();
    public static final Map<String, Integer> HARGA_MINUMAN = new HashMap<>();

    static {
        // Harga Makanan
        HARGA_MAKANAN.put("Indomie Kuah", 8000);
        HARGA_MAKANAN.put("Indomie Goreng", 7000);
        HARGA_MAKANAN.put("Fries & Sausages", 10000);

        // Harga Minuman
        HARGA_MINUMAN.put("Milktea Ice", 5000);
        HARGA_MINUMAN.put("Kopi", 4000);
        HARGA_MINUMAN.put("Air Mineral", 4500);
    }
}