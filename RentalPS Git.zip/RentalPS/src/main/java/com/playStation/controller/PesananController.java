
package main.java.com.playStation.controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import main.java.com.playStation.model.BookingPesnan;
import main.java.com.playStation.view.pesanan;
import main.java.com.playStation.view.informasiPesanan;
import main.java.com.playStation.view.pembayaranCustomer;



public class PesananController {
    //properties menyimpan nilai
    private BookingPesnan booking;
    private pesanan pesan;
    private final pembayaranCustomer bayarStruk;
    
    
    
    //construktor
    public PesananController(BookingPesnan model, pesanan view){
        this.booking = model;
        this.pesan = view;
        this.bayarStruk = new pembayaranCustomer(this);
    }
    
    
    //getter setter
    public BookingPesnan getBooking() {
        return booking;
    }

    public void setBooking(BookingPesnan booking) {
        this.booking = booking;
    }

    public pesanan getPesan() {
        return pesan;
    }

    public void setPesan(pesanan pesan) {
        this.pesan = pesan;
    }
    
    
    
    //method ambil nilai untuk ke struk
    List<String> daftarStruk = new ArrayList<>();
    public void ambilNilai() {
        // 2. Ambil nilai dari setiap komponen di form
        booking.setJenisPS(pesan.getComboPs().getSelectedItem().toString()); 
        booking.setNomorPod1(pesan.getComboPodPs4().getSelectedItem().toString());
        booking.setNomorPod2(pesan.getComboPodPs5().getSelectedItem().toString());
        booking.setDurasi(Integer.parseInt(pesan.getTxtFieldDurasi().getText()));
        booking.setNamaCustomer(pesan.getTxtFieldCustomer().getText()); 
        booking.setJenisMakanan(pesan.getComboMakanan().getSelectedItem().toString()); 
        booking.setJumlahMakanan(Integer.parseInt(pesan.getJmlhFieldMakan().getText()));
        booking.setJenisMinuman(pesan.getComboMinuman().getSelectedItem().toString()); 
        booking.setJumlahMinuman(Integer.parseInt(pesan.getJmlhFieldMinum().getText()));
        booking.setTambahanStik(Integer.parseInt(pesan.getComboStik().getSelectedItem().toString()));

        //nilai masuk ke list
        daftarStruk.clear(); 
        daftarStruk.add("PS Yang Dipilih  : " + booking.getJenisPS());
        
        //nomor pod
        if (!booking.getNomorPod1().equals("-")) {
        daftarStruk.add("Nomor Pod        : " + booking.getNomorPod1());
        }
        else if (!booking.getNomorPod2().equals("-")) {
        daftarStruk.add("Nomor Pod        : " + booking.getNomorPod2());
        }
        
        daftarStruk.add("Durasi Bermain   : " + booking.getDurasi() + " Jam");
        daftarStruk.add("Nama Customer    : " + booking.getNamaCustomer());
        daftarStruk.add("Makanan          : " + booking.getJenisMakanan());
        daftarStruk.add("Jumlah Makanan   : " + booking.getJumlahMakanan());
        daftarStruk.add("Minuman          : " + booking.getJenisMinuman());
        daftarStruk.add("Jumlah Minuman   : " + booking.getJumlahMinuman());
        daftarStruk.add("Tambahan Stik Ps : " + booking.getTambahanStik());
        
        //tampil di Struk
        pesan.getDaftarTxtArea().setText(""); 
        for (String baris : daftarStruk) {
        pesan.getDaftarTxtArea().append(baris + "\n");
        }   
        
    }
    
    


    
    
    
    //method pindah ke frame informasiPesanan
    informasiPesanan infoFrame = new informasiPesanan(booking, this);
    public void pindahFrame() {
        //isi textField yang ada di informasiPesanan
        ambilNilai();
        
        
        infoFrame.getConsoleTxtField().setText(booking.getJenisPS());        
        //cek pod aktif
        String pod;
        if (! booking.getNomorPod1().equals("-")) {
            pod = booking.getNomorPod1(); 
        } else {
            pod = booking.getNomorPod2(); 
        }
        infoFrame.getPodTxtField().setText(pod);
        infoFrame.getDurasiTxtField().setText(booking.getDurasi() + " Jam");
        infoFrame.getNamaTxtField().setText(booking.getNamaCustomer());
        
        //isi textArea
        infoFrame.getTambahanTxtArea().setText("");
        infoFrame.getTambahanTxtArea().append(booking.getJenisMakanan() + " (" + booking.getJumlahMakanan() + ")\n");
        infoFrame.getTambahanTxtArea().append(booking.getJenisMinuman() + " (" + booking.getJumlahMinuman() + ")\n");
        infoFrame.getTambahanTxtArea().append("Stik PS ("+booking.getTambahanStik()+")\n"); 
        infoFrame.setVisible(true);
        pesan.dispose();
         
    }
    
    //method pindah ke pembayaranCustomer
    
    public void pindahFrame2() {
        ambilNilai();
        
        //hitung total bayar
        int total = 0;
        
        // Hitung harga sewa PS berdasarkan jenis PS yang sudah disimpan
        if (booking.getJenisPS().equals("PlayStation 4")) {
            total += booking.getDurasi() * 10000; // Harga untuk PS4
        } else if (booking.getJenisPS().equals("PlayStation 5")) {
            total += booking.getDurasi() * 15000; // Harga untuk PS5
        }

        //Hitung harga makanan
        if (BookingPesnan.HARGA_MAKANAN.containsKey(booking.getJenisMakanan())) {
            int hargaMakanan = BookingPesnan.HARGA_MAKANAN.get(booking.getJenisMakanan());
            total += hargaMakanan * booking.getJumlahMakanan();
        }

        // itung harga minuman
        if (BookingPesnan.HARGA_MINUMAN.containsKey(booking.getJenisMinuman())) {
            int hargaMinuman = BookingPesnan.HARGA_MINUMAN.get(booking.getJenisMinuman());
            total += hargaMinuman * booking.getJumlahMinuman();
        }

        //Hitung tambahan stik
        int hargaStik = 5000;
        total += booking.getTambahanStik() * hargaStik;

        //Set ke model
        booking.setTotalHarga(total);
        
        //masukkan ke field
        bayarStruk.getTotalBayarField().setText(String.valueOf(total));
        
        
        
        
        bayarStruk.getStrukBayarTxtArea().setText("\n");
        bayarStruk.getStrukBayarTxtArea().append("UNIKOM RENTAL PS\n");
        bayarStruk.getStrukBayarTxtArea().append("Jenis PS      : "+booking.getJenisPS()+"\n");
        
        String pod;
        if (! booking.getNomorPod1().equals("-")) {
            pod = booking.getNomorPod1(); 
        } else {
            pod = booking.getNomorPod2(); 
        }
        
        bayarStruk.getStrukBayarTxtArea().append("POD           : "+pod+"\n");
        bayarStruk.getStrukBayarTxtArea().append("Durasi        : "+booking.getDurasi()+" Jam \n");
        bayarStruk.getStrukBayarTxtArea().append("Nama Customer : "+booking.getNamaCustomer()+"\n");
        bayarStruk.getStrukBayarTxtArea().append("\n");
        bayarStruk.getStrukBayarTxtArea().append("TAMBAHAN\n");
        bayarStruk.getStrukBayarTxtArea().append("Makanan       : "+booking.getJenisMakanan()+" ("
                                                                   +booking.getJumlahMakanan()+")\n");
        bayarStruk.getStrukBayarTxtArea().append("Minuman       : "+booking.getJenisMinuman()+"("
                                                                   +booking.getJumlahMinuman()+")\n");
        bayarStruk.getStrukBayarTxtArea().append("Stik PS ("+booking.getTambahanStik()+")\n");
        bayarStruk.getStrukBayarTxtArea().append("\n");
        bayarStruk.getStrukBayarTxtArea().append("TERIMAKASIH SUDAH BERKUNJUNG :D \n");
        
        bayarStruk.setVisible(true);
        infoFrame.dispose();
    }
    
    
    //method kembalian
    public void hitungKembalian() {
        try {
            //Ambil total harga yang sudah tersimpan di model
            int totalHarga = booking.getTotalHarga();
            
            //Ambil nominal bayar dari JTextField di frame pembayaran
            
            String nominalBayarStr = bayarStruk.getNominalBayarFIeld().getText();

            //Validasi jika input kosong
            if (nominalBayarStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(bayarStruk, "Harap masukkan nominal pembayaran.", "Input Kosong", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int nominalBayar = Integer.parseInt(nominalBayarStr);

            //Validasi jika uang yang dibayarkan kurang
            if (nominalBayar < totalHarga) {
                JOptionPane.showMessageDialog(bayarStruk, "Jumlah uang yang dibayarkan kurang!", "Transaksi Gagal", JOptionPane.ERROR_MESSAGE);
                return; // Keluar dari method jika uang kurang
            }
            
            //Hitung kembalian jika uang cukup
            int kembalian = nominalBayar - totalHarga;

            //Tampilkan kembalian di JTextField yang sesuai (dengan format Rupiah)
            bayarStruk.getKembalianField().setText(String.format("Rp %,d", kembalian));
            
            
            JOptionPane.showMessageDialog(bayarStruk, "Pembayaran berhasil! Kembalian Anda adalah " + String.format("Rp %,d", kembalian), "Sukses", JOptionPane.INFORMATION_MESSAGE);

            } catch (NumberFormatException e) {
                
                JOptionPane.showMessageDialog(bayarStruk, "Harap masukkan nominal bayar dalam bentuk angka yang valid.", "Input Tidak Valid", JOptionPane.ERROR_MESSAGE);
            }
            
        
    }
    
    
    
    
        
}
