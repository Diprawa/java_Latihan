
package main.java.com.playStation.controller;
import javax.swing.JOptionPane;
import main.java.com.playStation.model.LoginModel;
import main.java.com.playStation.view.admin_Login;
import main.java.com.playStation.view.tampilan_Utama2;

public class LoginController {
    //properties untuk menyimpan ke model dan login
    private LoginModel loginModel;
    private admin_Login adminLogin;
    
    //construktor
    public LoginController(LoginModel model, admin_Login view) {
        this.loginModel = model;
        this.adminLogin = view;
    }
    
    //getter setter
    public LoginModel getLoginModel() {
        return loginModel;
    }

    public void setLoginModel(LoginModel loginModel) {
        this.loginModel = loginModel;
    }

    public admin_Login getAdminLogin() {
        return adminLogin;
    }

    public void setAdminLogin(admin_Login adminLogin) {
        this.adminLogin = adminLogin;
    }
    
    //method login button
    public void prosesLogin() {
        String user = adminLogin.getTxtLogin().getText();
        String pass = adminLogin.getTxtPassword().getText();

        if (loginModel.checkLogin(user, pass)) {
            JOptionPane.showMessageDialog(null, "Login berhasil!");
            tampilan_Utama2 tampilanUtama = new tampilan_Utama2();
            tampilanUtama.setVisible(true);
            adminLogin.dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Login gagal! Username atau Password salah");
        }
    }
}
